#!/bin/bash

sudo rm -R /usr/local/brModelo.2.0 

sudo rm -R /bin/brModelo

sudo cp -r brmodelo /usr/local/

sudo cp brModelo /bin/

sudo chmod +x /bin/brModelo
 
